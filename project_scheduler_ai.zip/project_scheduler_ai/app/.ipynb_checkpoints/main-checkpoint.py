from fastapi import FastAPI
from schemas import ProjectInput
from model_loader import load_models
from predictor import enrich_project

app = FastAPI()

models = load_models()

@app.post("/predict")
def predict(project: ProjectInput):
    enriched = enrich_project(project.dict(), models)
    return enriched